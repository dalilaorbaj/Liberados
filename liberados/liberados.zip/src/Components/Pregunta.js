import React from "react";
import '../global.css';

const Pregunta = ({id}) => {
    return (    
        <noscript>FETCH THE QUESTION WITH THE ID HERE</noscript>
    );
}
export default Pregunta